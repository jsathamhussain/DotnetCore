﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http;

namespace MVCCore.Models
{
    public class Books
    {
		public string Publisher { get; set; }
		public string Title { get; set; }
		public string AuthorLastName { get; set; }
		public string AuthorFirstName { get; set; }
		public decimal Price { get; set; }
		public IFormFile BookImage { get; set; }
		public int Year { get; set; }
		public string City { get; set; }
		public string Medium { get; set; }
        public string PublicationPlace { get; set; }
        public int Edition { get; set; }
        public string ImageBase64 { get; set; }

        public string MLACitation
        {
            get
            {
                string authorLastName = AuthorLastName;
                string authorFirstName = AuthorFirstName;
                string title = Title;
                string publisher = Publisher;
                int year = Year;
                string city = City;
                string medium = Medium;

                string citation = $"{authorLastName}, {authorFirstName}. {title}. {publisher}, {year}.";
                if (!string.IsNullOrEmpty(city))
                {
                    citation += $" {city}.";
                }
                if (!string.IsNullOrEmpty(medium))
                {
                    citation += $" {medium}.";
                }

                return citation;
            }
        }

        public string ChicagoCitation
        {
            get
            {
                string authorLastName = AuthorLastName;
                string authorFirstName = AuthorFirstName;
                string title = Title;
                string publisher = Publisher;
                int year = Year;
                string publicationPlace = PublicationPlace;
                int edition = Edition;

                string citation = $"{authorLastName}, {authorFirstName}. <i>{title}</i>. {publicationPlace}: {publisher}, {year}.";
                if (edition > 1)
                {
                    citation += $" Edition - {edition}";
                }

                return citation;
            }
        }
    }
}
