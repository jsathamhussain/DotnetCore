﻿using Microsoft.AspNetCore.Mvc;
using MVCCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Diagnostics;

namespace MVCCore.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet("getbookswithmlacitation")]
        public IActionResult GetBooksWithMLACitation()
        {
            List<Books> books = GetBooksData();
            string mlaCitation = string.Empty;
            foreach (var book in books)
            {
                mlaCitation += book.MLACitation + "; ";
            }
            return Ok(mlaCitation);
        }

        [HttpGet("getbookswithchicagocitation")]
        public IActionResult GetBooksWithChicagoCitation()
        {
            List<Books> books = GetBooksData();
            string chicagoCitation = string.Empty;
            foreach (var book in books)
            {
                chicagoCitation += book.ChicagoCitation + "; ";
            }
            return Ok(chicagoCitation);
        }

        [HttpGet("sortedbyauthor")]
        public IActionResult GetBooksSortedByAuthor()
        {
            List<Books> books = GetBooksData();
            var sortedBooks = books.OrderBy(b => b.AuthorLastName)
                                    .ThenBy(b => b.AuthorFirstName)
                                    .ThenBy(b => b.Title)
                                    .ToList();
            ModelState.Clear();
            ViewData["NewModel"] = sortedBooks;
            return Ok(sortedBooks);
            //return RedirectToAction("Index", sortedBooks);
            //turn View(sortedBooks);
        }

        // Method to return a sorted list of books by Publisher, Author (last, first), then title
        [HttpGet("sortedbypublisher")]
        public IActionResult GetBooksSortedByPublisher()
        {
            List<Books> books = new List<Books>();

            using (SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                SqlCommand command = new SqlCommand("GetBooksSortedByPublisherAuthorTitle", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Books book = new Books
                    {
                        Publisher = reader["Publisher"].ToString(),
                        Title = reader["Title"].ToString(),
                        AuthorLastName = reader["AuthorLastName"].ToString(),
                        AuthorFirstName = reader["AuthorFirstName"].ToString(),
                        Price = decimal.Parse(reader["Price"].ToString()),
                        ImageBase64 = reader["ImageBase64"].ToString()
                    };

                    books.Add(book);
                }
            }

            return Ok(books);
        }

        // Method to return a sorted list of books by Author (last, first), then title
        [HttpGet("sortedbyauthorsql")]
        public IActionResult GetBooksSortedByAuthorSql()
        {
            List<Books> books = new List<Books>();

            using (SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                SqlCommand command = new SqlCommand("GetBooksSortedByAuthorTitle", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Books book = new Books
                    {
                        Publisher = reader["Publisher"].ToString(),
                        Title = reader["Title"].ToString(),
                        AuthorLastName = reader["AuthorLastName"].ToString(),
                        AuthorFirstName = reader["AuthorFirstName"].ToString(),
                        Price = decimal.Parse(reader["Price"].ToString()),
                        ImageBase64 = reader["ImageBase64"].ToString()
                    };

                    books.Add(book);
                }
            }

            return Ok(books);
        }

        [HttpGet("totalprice")]
        public IActionResult GetTotalPrice()
        {
            decimal totalPrice = 0;

            using (SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                SqlCommand command = new SqlCommand("SELECT SUM(Price) FROM Books", connection);
                connection.Open();

                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                {
                    totalPrice = Convert.ToDecimal(result);
                }
            }

            return Ok(totalPrice);
        }

        [HttpPost("savebook")]
        public IActionResult BulkInsertBooks(List<Books> books)
        {
            using (SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                connection.Open();

                // Create a DataTable to hold the book data
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Publisher", typeof(string));
                dataTable.Columns.Add("Title", typeof(string));
                dataTable.Columns.Add("AuthorLastName", typeof(string));
                dataTable.Columns.Add("AuthorFirstName", typeof(string));
                dataTable.Columns.Add("Price", typeof(decimal));
                dataTable.Columns.Add("BookImage", typeof(string));

                // Populate the DataTable with book data
                foreach (Books book in books)
                {
                    dataTable.Rows.Add(
                        book.Publisher,
                        book.Title,
                        book.AuthorLastName,
                        book.AuthorFirstName,
                        book.Price,
                        book.BookImage
                    );
                }

                // Use SqlBulkCopy to perform bulk insert
                using SqlBulkCopy bulkCopy = new SqlBulkCopy(connection);
                bulkCopy.DestinationTableName = "Books"; // Replace with your actual table name
                bulkCopy.WriteToServer(dataTable);
            }

            return Ok();
        }

        [HttpPost]
        public IActionResult SaveBook(Books book, IFormFile imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con
                };
                cmd.Parameters.AddWithValue("@Publisher", book.Publisher);
                cmd.Parameters.AddWithValue("@Title", book.Title);
                cmd.Parameters.AddWithValue("@AuthorLastName", book.AuthorLastName);
                cmd.Parameters.AddWithValue("@AuthorFirstName", book.AuthorFirstName);
                cmd.Parameters.AddWithValue("@Price", book.Price);
                cmd.Parameters.AddWithValue("@ImageBase64", book.ImageBase64);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertBook";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
                
            return RedirectToAction("Index", book);
        }
                
        [HttpGet]
        public IActionResult Index()
        {
            List<Books> books = GetBooksData();
            ViewData["NewModel"] = books;
            return View(books);
        }
        public static async Task<string> ReadFormFileAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return await Task.FromResult((string)null);
            }

            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                return await reader.ReadToEndAsync();
            }
        }
        public List<Books> GetBooksData()
        {
            List<Books> books = new List<Books>();
            using (SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                SqlCommand command = new SqlCommand("GetBooksData", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Books book = new Books
                    {
                        Publisher = reader["Publisher"].ToString(),
                        Title = reader["Title"].ToString(),
                        AuthorLastName = reader["AuthorLastName"].ToString(),
                        AuthorFirstName = reader["AuthorFirstName"].ToString(),
                        Price = decimal.Parse(reader["Price"].ToString()),
                        ImageBase64 = reader["ImageBase64"].ToString(),
                        Year = Int32.Parse(reader["Year"].ToString()),
                        City = reader["City"].ToString(),
                        PublicationPlace = reader["PublicationPlace"].ToString(),
                        Edition = Int32.Parse(reader["Edition"].ToString())
                    };

                    books.Add(book);
                }
            }
            return books;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}